from django.shortcuts import render
from django.http import HttpResponse
from . models import Alumnos
# Create your views here.
def index(request):
    return HttpResponse("Hello, world. You're at the polls index.")

def index_alumnos(request):
    alumnos = Alumnos.objects.order_by('nombre')
    output = ', '.join([d.nombre for d in alumnos])
    context = {'lista_alumnos': alumnos}
    return render(request, 'index.html', context)