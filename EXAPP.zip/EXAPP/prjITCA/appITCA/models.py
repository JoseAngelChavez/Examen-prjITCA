from django.db import models

# Create your models here.
class Alumnos(models.Model):
    nombre = models.CharField(max_length=100)
    dirección = models.CharField(max_length=150)
    teléfono = models.IntegerField()
    email = models.EmailField()
    hobbies = models.CharField(max_length=100)